package com.example.klant.mydietapp;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import android.content.Context;

import org.xml.sax.ContentHandler;

import static com.example.klant.mydietapp.R.id.tv_steps;


public class overweight extends _SwipeActivityClass
        implements  SensorEventListener {

        SensorManager sensorManager;

    int in;
    Animation Fade_in,Fade_out;
    ImageSwitcher imageSwitcher;

    Integer [] images = {
            R.drawable.water,R.drawable.proteins,
            R.drawable.sport,R.drawable.possitive
    };

    public void goToSecondMain(){
        Intent intentSecondMain = new Intent(this, Main2Activity.class);
        startActivity(intentSecondMain);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overweight);
       // Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);
        imageSwitcher = (ImageSwitcher)findViewById(R.id.imageSwitcher1);
        in = images.length - 1;
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
                return imageView;
            }
        });
        Fade_in = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.layout);
        Fade_out = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.out);

        imageSwitcher.setInAnimation(Fade_in);
        imageSwitcher.setOutAnimation(Fade_out);


        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


    }


    @Override
    protected void onResume(){
        super.onResume();
        Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if(countSensor!= null){
            sensorManager.registerListener(this, countSensor, SensorManager.SENSOR_DELAY_UI);
        }
        else{
            Toast.makeText(this, "Sensor not found", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onPause() {
        super.onPause();
        //sensorManager.unregisterListener(this);
    }
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (in >= 0){
            imageSwitcher.setImageResource(images[in]);
        }
        else{
            in = images.length - 1;
            imageSwitcher.setImageResource(images[in]);
        }
        in--;
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


    @Override
    protected void onSwipeRight()
    {
        goToSecondMain();
    }

    @Override
    protected void onSwipeLeft()
    {
        goToSecondMain();
    }


}