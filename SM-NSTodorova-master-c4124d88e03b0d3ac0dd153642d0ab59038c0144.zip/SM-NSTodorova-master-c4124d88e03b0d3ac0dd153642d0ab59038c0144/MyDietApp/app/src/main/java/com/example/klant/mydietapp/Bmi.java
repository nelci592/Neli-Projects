package com.example.klant.mydietapp;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
/**
 * Created by klant on 9/27/17.
 */

public class Bmi {
    private double weight;
    private double height;
    private double bmi;
    public static ArrayList<Bmi>bmis = new ArrayList<Bmi>();
    String date;


    public Bmi(double weight, double height, double bmi){
        date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        this.weight=weight;
        this.height=height;
        this.bmi = weight / (height*height);


    }
    public void setBmi(double bmi){

        bmi = weight / (height*height);
    }

    public void setWeight(double weight){
        this.weight=weight;
    }

    public void setHeight(double height){
        this.height=height;
    }


    public Double getWeight(){
        return weight;
    }
    public String getDate(){return date;}
    public Double getHeight(){
        return height;
    }
    public Double getBmi(){
        return bmi;
    }




}

