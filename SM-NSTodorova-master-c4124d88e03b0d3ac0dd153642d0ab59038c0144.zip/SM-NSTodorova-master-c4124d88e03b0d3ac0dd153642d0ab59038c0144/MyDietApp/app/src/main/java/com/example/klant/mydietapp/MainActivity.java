package com.example.klant.mydietapp;



import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import java.io.FileOutputStream;
import android.content.Context;
import java.io.File;
import java.lang.String;
import java.io.File;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.io.*;
import java.util.StringTokenizer;


public class MainActivity extends  _SwipeActivityClass {
    private static final String TAG = "dasjaojdsaj";
    private GestureDetectorCompat gestureObject;



    public void goToLoadActivity(){
        Intent intentLoad = new Intent(this, loadact.class);
        startActivity(intentLoad);
    }

    public void goToSteps(){
        Intent intentSteps = new Intent(this, steps.class);
        startActivity(intentSteps);
    }

    public void goToSecondMain(){
        Intent intentSecondMain = new Intent(this, Main2Activity.class);
        startActivity(intentSecondMain);
    }

    public Button save, load,button_calc;
    public String path= Environment.getExternalStorageDirectory().getAbsolutePath();
    public double bmi;
    //ArrayList<Bmi>bmis;



    EditText field_weight,field_height;
    TextView view_result, view_msg;




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        field_weight = (EditText) findViewById((R.id.field_weight));
        field_height = (EditText) findViewById((R.id.field_height));
        view_result= (TextView) findViewById(R.id.view_result);
        view_msg= (TextView) findViewById(R.id.view_msg);

        button_calc = (Button) findViewById(R.id.button_calc);
        save=(Button) findViewById(R.id.save);
        load=(Button) findViewById(R.id.load);

        File dir = new File(path);
        dir.mkdirs();

        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToLoadActivity();
            }
        });

    }
        //loadData() ;


       // gestureObject= new GestureDetectorCompat(this, new GestureClass());
        Intent intent= getIntent();

        public void buttonCalculate(View v){
            double weight= Double.parseDouble(field_weight.getText().toString());
            double height= Double.parseDouble(field_height.getText().toString());
            double bmi;
            String msg = "";
            if (field_height.getText().toString().equals("") || field_weight.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "No valid values", Toast.LENGTH_LONG);

            } else {



                bmi = height * height;
                bmi = weight / bmi;
                view_result.setText(String.valueOf(bmi));

                if (bmi < 18.5) {
                    msg = "Underweight";
                } else if (bmi > 18.5 && bmi < 25) {
                    msg = "Normal";
                } else if (bmi > 25) {
                    msg = "Overweight";
                }
                view_msg.setText(msg);
              //  String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                Bmi newBmi= new Bmi( weight, height, bmi);
                Bmi.bmis.add(newBmi);
            }

        }

        




        public void buttonSave (View v){



        try
        {

        FileOutputStream file = openFileOutput("Data.txt", MODE_PRIVATE);
            OutputStreamWriter outputFile = new OutputStreamWriter(file);
            for (int i=0; i<Bmi.bmis.size(); i++)
            {
                outputFile.write( " " + Bmi.bmis.get(i).getWeight()+ " " + Bmi.bmis.get(i).getHeight()+ " " + Bmi.bmis.get(i).getBmi());

            }
                outputFile.flush();;
                outputFile.close();
            Toast.makeText(MainActivity.this, "Successfully saved!", Toast.LENGTH_SHORT).show();
        }
        catch (IOException e)
        {
            Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        }



    @Override
    protected void onSwipeRight()
    {
        goToSteps();
    }

    @Override
    protected void onSwipeLeft()
    {
        goToSecondMain();
    }

    public void toast(String message)
    {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }



}



