package com.example.klant.mydietapp;

import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class underweight extends AppCompatActivity {




    ViewPager viewPager;
    swipe  customSwip;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_underweight);
        viewPager=(ViewPager)findViewById(R.id.viewPager);
        customSwip=new swipe(this);
        viewPager.setAdapter(customSwip);
    }




}
