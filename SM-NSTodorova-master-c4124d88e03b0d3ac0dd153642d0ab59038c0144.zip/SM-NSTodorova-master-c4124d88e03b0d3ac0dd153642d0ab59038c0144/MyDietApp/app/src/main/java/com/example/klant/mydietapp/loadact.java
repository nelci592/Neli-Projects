package com.example.klant.mydietapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class loadact extends _SwipeActivityClass {

    //ArrayList<Bmi> bmis;
    TextView tv_bmis;
    public void goToMain(){
        Intent intentMain = new Intent(this, MainActivity.class);
        startActivity(intentMain);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loadact);
        tv_bmis=(TextView)findViewById(R.id.tv_bmis);
        loadData();
    }

    private void setTextToTextView(){
        String text="";
        for (int i=0; i<Bmi.bmis.size(); i++ )
        {
            text=text+ " " + Bmi.bmis.get(i).getWeight()+ " " + Bmi.bmis.get(i).getHeight()+ " " + Bmi.bmis.get(i).getBmi();
            tv_bmis.setText(text);
        }
    }


    public void loadData(){
        //bmis.clear();
        File file = getApplicationContext().getFileStreamPath("Data.txt");
        String lineFromFile;

        if(file.exists())
            try
            {
                BufferedReader reader= new BufferedReader(new InputStreamReader(openFileInput("Data.txt")));
                while ((lineFromFile= reader.readLine())!=null)
                {

                    StringTokenizer tokens = new StringTokenizer(lineFromFile, " ");
                    Bmi newBmi = new Bmi(Double.parseDouble(tokens.nextToken()), Double.parseDouble(tokens.nextToken()), Double.parseDouble( tokens.nextToken()));
                }
                reader.close();
                setTextToTextView();
            }
            catch(IOException e)
            {
                Toast.makeText(loadact.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

    }

    @Override
    protected void onSwipeRight()
    {
        goToMain();
    }

    @Override
    protected void onSwipeLeft()
    {

        goToMain();
    }
}
