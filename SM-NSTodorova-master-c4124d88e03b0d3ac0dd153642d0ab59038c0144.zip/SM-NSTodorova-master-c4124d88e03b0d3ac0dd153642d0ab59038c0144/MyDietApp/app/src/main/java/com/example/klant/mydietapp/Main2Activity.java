package com.example.klant.mydietapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends  _SwipeActivityClass {
    public void goToSteps(){
        Intent intentSteps = new Intent(this, steps.class);
        startActivity(intentSteps);
    }

    public void goToMain(){
        Intent intentMain = new Intent(this, MainActivity.class);
        startActivity(intentMain);
    }




    public void overweightActivity(){
        Intent intent1= new Intent(this, overweight.class);
        startActivity(intent1);

    }


    public void underweight(){
        Intent intent2= new Intent(this, underweight.class);
        startActivity(intent2);

    }

    /*
    *
     * for the third thing
      * public void underweight(){
        Intent intent2= new Intent(this, underweight.class);
        startActivity(intent2);

    }

    * */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final Button btn_overweight= (Button) findViewById(R.id.btn_overweight);
        final Button btn_underweight= (Button) findViewById(R.id.btn_underweight);
        final Button btn_else= (Button) findViewById(R.id.btn_else);
        Intent intent= getIntent();

        btn_underweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                underweight();
            }
        });

        btn_overweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                overweightActivity();
            }
        });
    }


    @Override
    protected void onSwipeRight()
    {
        goToMain();
    }

    @Override
    protected void onSwipeLeft()
    {

        goToSteps();
    }

}
