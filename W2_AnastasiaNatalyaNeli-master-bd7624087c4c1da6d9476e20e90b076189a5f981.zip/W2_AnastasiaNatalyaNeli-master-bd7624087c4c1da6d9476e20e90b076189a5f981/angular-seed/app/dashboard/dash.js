'use strict';

angular.module('myApp.dash', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/dash', {
    templateUrl: 'dashboard/dash.html',
    controller: 'DashCtrl'
  });
}])

.controller('DashCtrl', ['$scope', 'EmpFactory','depFactory', 'taskFactory',function($scope,EmpFactory,depFactory, taskFactory) {

}]);