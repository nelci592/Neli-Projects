'use strict';

angular.module('myApp.emp', ['ngRoute', 'ui.bootstrap','ngAnimate'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/emp', {
    templateUrl: 'emp/employee.html',
    controller: 'EmpoCtrl'
  });
}])


.filter('empFilter', function(){
        return function(input, text){
            return input.filter(function(item){
                return item.lastName.toLowerCase().startsWith(text.toLowerCase());
            });
        };
    })


.service('empService', ['$http','$q', function ($http, $q){
    this.getEmp = function(){
        return $http.get('http://i874156.iris.fhict.nl/WEB2/employees')
            .then(function(response) {
                var urlCalls = [];

                angular.forEach(response.data.slice(980,1000), function(emp) {
                    console.log("downloading the details for emp no:", emp.no);
                    urlCalls.push($http.get('http://i874156.iris.fhict.nl/WEB2/employees/' + emp.no));
                });

                return $q.all(urlCalls);
            })
    };
}])

.factory('EmpFactory',  function () {
    var employees = {};
    var empId = 10;
    employees.data = [
        {firstName: 'Chris', lastName: 'Doe', id: 1, email: 'abc@mail.com',departmentId: 1, taskId:1},
        {firstName: 'Bina', lastName: 'Surya', id: 2, email: 'def@mail.com',departmentId: 2, taskId:2},
        {firstName: 'Koko', lastName: 'Opas', id: 3, email: 'ghi@mail.com',departmentId: 3, taskId:3},
        {firstName: 'Anri', lastName: 'Lova', id: 4, email: 'jkl@mail.com',departmentId: 4, taskId:4},
        {firstName: 'Bill', lastName: 'Trin', id: 5, email: '123@mail.com',departmentId: 1},
        {firstName: 'Ronald', lastName: 'Vinch', id: 6, email: '456@mail.com',departmentId: 2, taskId:2},
        {firstName: 'Sandy', lastName: 'Cheeks', id: 7, email: '789@mail.com',departmentId: 3},
        {firstName: 'Sam', lastName: 'Uel', id: 8, email: '1a1@mail.com',departmentId: 4},
        {firstName: 'Yup', lastName: 'Peh', id: 9, email: '2v2@mail.com',departmentId: 6, taskId:6},
        {firstName: 'Kate', lastName: 'Shrin', id: 10, email: 'ss4@mail.com',departmentId: 5, taskId:5}
    ];
    employees.deplist =[];
    employees.addToFactory = function (emplo) {
        empId++;
        emplo.id = empId;
        this.employees.push(emplo);
    }
    employees.getData = function() {
        return employees.data;
    };

    employees.getEmployeesforTask=function (taskid) {
        var newlistemp=[];
        for(var index=0;index<employees.data.length;index++)
        {
            var employee=employees.data[index];
            if(employee.taskId==taskid)
            {
                newlistemp.push(employee);
            }
        }
        return newlistemp;
    }

    employees.getEmployeesForDepartment = function(searchedId) {
        var newlistforemployees=[];

        for(var index=0; index < employees.data.length; index++)
        {
            var employee=employees.data[index];

            if(employee.departmentId == searchedId)
            {
                newlistforemployees.push(employee);

            }
        }

        return newlistforemployees;
    };

    return employees;
})

.controller('EmpoCtrl', ['$scope', 'EmpFactory','depFactory','empService',function($scope,EmpFactory,depFactory,empService) {


    //$scope.employeeInfo = EmpFactory.getData();
    $scope.searchName="";
    $scope.employeesList = [];
    $scope.genders = ["M", "F"];
    $scope.departmentsIdList =[];


    empService.getEmp()
        .then(function(responses){
            angular.forEach(responses, function(response) {
                $scope.employeesList.push(response.data);
            });
        }, function (error) { $scope.error=error; });


    $scope.add = function (emplo) {
            var index=getSelectedIndex($scope.no);
            var counter = 0;
            //var letters =/ ^[0-9 \-]+$/;


            if ( $scope.firstName == null || $scope.hireDate == null || $scope.birthDate == null || $scope.deptId == null ){
                alert("please give value for first name, hire date, birth date, and deptID")
            }
            //else if(depFactory.compareIds($scope.depid)==null)
            // alert(" department ID non existent"//}
            //else if ($scope.hireDate =! letters) //{// alert("please use numbers and hyphen")//}
            else{
                counter++;
                //$scope.no = $scope.employeesList.length + counter;
                $scope.no = 11000 + counter;
                $scope.employeesList.push( {
                    no: $scope.no, firstName: $scope.firstName, lastName: $scope.lastName, hireDate: $scope.hireDate,
                    gender: $scope.gender, birthDate: $scope.birthDate, departments: {no: $scope.deptId},
                    tasks: []});



                $scope.no = null;
                $scope.firstName='';
                $scope.lastName='';
                $scope.gender='';
                $scope.birthDate='';
                $scope.hireDate='';
                $scope.departments='';
                $scope.deptId='';
                $scope.tasks='';}

        }


        $scope.remove = function (emplo) {
            var index = $scope.employeesList.indexOf(emplo);
            if(index != -1)
                var result=confirm("Are you sure you want to delete?");
            if(result==true)
            {$scope.employeesList.splice(index,1);}
        };

        $scope.selectEdit=function(no){
            console.log("edit no:", no);
            var index = getSelectedIndex(no);
            console.log("index:", index);
            var emp = $scope.employeesList[index];
            console.log("emp:", index);
            $scope.no = no;
            $scope.firstName = emp.firstName;
            $scope.lastName = emp.lastName;
            $scope.departments=emp.departments;




        };
        $scope.save=function(){
            console.log("save()");
            var index=getSelectedIndex($scope.no);
            console.log("index:", index);

                $scope.employeesList[index].no = $scope.no;
                $scope.employeesList[index].firstName = $scope.firstName;
                $scope.employeesList[index].lastName = $scope.lastName;
//                $scope.employeesList[index]=$scope.departments;
        };



        function getSelectedIndex(no){
            for (var i = 0; i < $scope.employeesList.length; i++)
                if ($scope.employeesList[i].no == no)
                    return i;
            return -1;
        }
}])


.directive('empDirective', function(){
    return{
        restrict:'E',
        replace: true,
        scope: {emplo:'='},
        templateUrl:'emp/emptemp.html'

    };
});
