'use strict';

angular.module('myApp.dep', ['ngRoute','ui.bootstrap','ngAnimate'])
    .filter('depFilter', function(){
        return function(input, text){

            return input.filter(function(item){

                return item.name.toLowerCase().startsWith(text.toLowerCase()) || item.no==(+text);
            });
        };
    })
    .filter('empDetailFilter', function(){
        return function(input, text){
            return input.filter(function(item){
                return item.toDate == text;
            });
        };
    })
    .service('depService',['$http','$q', function ($http, $q) {
        this.getDep=function () {
            return $http.get('http://i874156.iris.fhict.nl/WEB2/departments')
                .then(function(response) {
                    var urlCalls = [];

                    angular.forEach(response.data, function(dep) {
                        // console.log("downloading the details for department no:", dep.no);
                        urlCalls.push($http.get('http://i874156.iris.fhict.nl/WEB2/departments/' + dep.no));
                    });

                    return $q.all(urlCalls);
                })
        };
    }])
    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/dep', {
            templateUrl: 'dep/departments.html',
            controller: 'DepCtrl'
        });
    }])
    .controller('DepCtrl', ['$scope','depFactory', 'depService',function($scope,depFactory,depService) {
      //  $scope.departmentsInfo = depFactory.getData();
        $scope.departmentsList = [];
        $scope.searchText="";
        $scope.loading = true;

        depService.getDep()
            .then(function (responses) {
                angular.forEach(responses, function(response) {
                    $scope.departmentsList.push(response.data);
                });

                $scope.loading = false;
            }, function (error) { $scope.error=error; });


        $scope.add=function(dep) {
            var index = getSelectedIndex($scope.no);

            if ($scope.name == null || $scope.code == null) {
                alert("Please give value for  department name and code")
            }
            else {
                $scope.no = $scope.departmentsList.length + 1;
                $scope.departmentsList.push({
                    no: $scope.no, name: $scope.name, code: $scope.code,employees:[]
                });

                $scope.no = null;
                $scope.name = null;
                $scope.code = '';
//                $scope.employees=[];
//                $scope.tasks = [];

                  }

        }
            $scope.save = function () {
                var index = getSelectedIndex($scope.no);
                $scope.departmentsList[index].no = $scope.no;
                $scope.departmentsList[index].name = $scope.name;
                $scope.departmentsList[index].code = $scope.code;
             //   $scope.departmentsList[index].employees = $scope.employees;
             //   $scope.departmentsList[index].tasks = $scope.tasks;

            //    $scope.departmentsList[index].number = $scope.number;
              //  $scope.departmentsList[index].taskId = $scope.taskId;
            };
//edit button function
            $scope.selectEdit = function (no) {
                var index = getSelectedIndex(no);
                var dep = $scope.departmentsList[index];
                $scope.no = dep.no;
                $scope.name = dep.name;
                $scope.code = dep.code;
                $scope.employees=dep.employees;
                $scope.tasks=dep.tasks;

            };
//delete button,asking a user if he really wants to delete
            $scope.del = function (no)
            {
                var result = confirm("Are you sure you want to delete?");
                if (result == true)
                {
                    var index = getSelectedIndex(no);
                    $scope.departmentsList.splice(index, 1);
                }
            };
            //gets an index for further functions
            function getSelectedIndex(no) {
                for (var i = 0; i < $scope.departmentsList.length; i++)
                    if ($scope.departmentsList[i].no == no)
                        return i;
                return -1;
            }
            }])

    .factory('depFactory', ['EmpFactory', function (EmpFactory) {
        var departments = {};
        var depId;
        departments.data = [
            {id: 1, name: "Production", code: 12,taskId:3},
            {id: 2, name: "Research", code: 13,taskId:1},
            {id: 3, name: "Purchasing", code: 14,taskId:2},
            {id: 4, name: "Marketing", code: 15,taskId:4},
            {id: 5, name: "Human Resource Management", code: 16,taskId:6},
            {id: 6, name: "Accounting", code: 17,taskId:5},
            {id: 7, name: "Development",code:18,taskId:5},
            {id: 8, name: "Finance",code:19,taskId: 2}
        ];

        departments.addToFactory=function (dep) {
            depId++;
            dep.id-depId;
            this.departments.push.data(dep);
        }

        departments.getDepartmentForTaskId=function (taskId) {
            for( var index=0;index<departments.data.length;index++)
            {
                var depTaskId=departments.data[index].taskId;
                if(taskId==depTaskId)
                {
                    return departments.data[index];
                }
            }
            return null;
        };
        departments.compareIds=function (empdepid) {
            for( var index=0;index<departments.data.length;index++)
            {
                if(empdepid == departments.data[index].id)
                {
                    return 1;
                }
            }
            return null;
        };
        //using Employee Factory to show employees in a department table
        departments.getData = function() {
            for(var index=0;index<departments.data.length;index++)
            {
                var department = departments.data[index];
                var list=  EmpFactory.getEmployeesForDepartment(department.id);
                department.employees = list;
            }
            return departments.data;
        };
        return departments;
    }])
    //directive
    .directive('depDirective',function () {
        return {
            restrict:'E',
            replace:true,
            scope:{dep:'='},
            // template: '<li><a ng-click="showDetails=! showDetails">{{dep.name}}</a> ' +
            //   '<div ng-show="showDetails"> {{dep.name}}'+
            // ' <div ng-repeat="emp in dep.employees"> {{emp.firstName}}</div>{{dep.taskId}}</div></li>'
            templateUrl:'dep/deptemp.html'
        };
    });