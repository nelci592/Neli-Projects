'use strict';
angular.module('myApp.tasks', ['ngRoute','ui.bootstrap','ngAnimate'])

    .service('taskService',['$http','$q', function ($http, $q) {
        this.getTask=function () {
            return $http.get('http://i874156.iris.fhict.nl/WEB2/tasks')
                .then(function(response) {
                    var urlCalls = [];

                    angular.forEach(response.data, function(tasks) {
                        urlCalls.push($http.get('http://i874156.iris.fhict.nl/WEB2/tasks/' + tasks.no));
                    });

                    return $q.all(urlCalls);
                })
        };
    }])
    .config (['$routeProvider', function ($routeProvider){
        $routeProvider.when('/tasks', {
            templateUrl: 'task/tasks.html',
            controller: 'TasksCtrl'
        });
    }])
    .controller('TasksCtrl', ['$scope', 'taskFactory', 'taskService',function($scope, taskFactory,taskService) {
    //    $scope.tasksInfo=taskFactory.getData();
        $scope.tasksList=[];
     //   $scope.loading=true;
       taskService.getTask()
           .then(function (responses) {
               angular.forEach(responses, function(response) {
                   $scope.tasksList.push(response.data);
               });
           }, function (error) { $scope.error=error; });

            $scope.add = function() {



            $scope.no =$scope.tasksList.length + 1;

            $scope.tasksList.push({
         no:$scope.no,deptNo:$scope.deptNo,title:$scope.title,description:$scope.description,status:$scope.status,finishedDate:$scope.finishedDate,modificationDate:$scope.modificationDate,creatioDate:$scope.creatioDate,
            });
                $scope.no=null;
                $scope.deptNo='';
                $scope.title='';
                $scope.description='';
                $scope.status='';
                $scope.finishedDate='';
                $scope.modificationdate='';
                $scope.creatioDate='';
        };
        $scope.del=function(no) {
            var result=confirm("Are you sure you want to delete?");
            if(result==true) {
                var index=getSelectedIndex(no);
                $scope.tasksList.splice(index,1);
            }
        };
        $scope.selectEdit=function(no) {
            var index=getSelectedIndex(no);
            var tasks = $scope.tasksList[index];

            $scope.no=tasks.no;
            $scope.deptNo=tasks.deptNo;
            $scope.title=tasks.title;
            $scope.description=tasks.description;
           $scope.status=tasks.status;
            $scope.finishedDate=tasks.finishedDate;
            $scope.modificationdate=tasks.modificationdate;
            $scope.creatioDate=tasks.creatioDate;
        };
        $scope.save=function(){
            var index=getSelectedIndex($scope.no);
            $scope.tasksList[index].no= $scope.no;
            $scope.tasksList[index].deptNo=$scope.deptNo;
            $scope.tasksList[index].title=$scope.title;
            $scope.tasksList[index].description=$scope.description;
            $scope.tasksList[index].status=$scope.status;
            $scope.tasksList[index].finishedDate=$scope.finishedDate;
            $scope.tasksList[index].modificationdate=$scope.modificationdate;
            $scope.tasksList[index].creatioDate=$scope.creatioDate;
        };
        function getSelectedIndex(no) {
            for (var i = 0; i < $scope.tasksList.length; i++) {
                if ($scope.tasksList[i].no == no)
                    return i;
            }
            return -1;
        }
    }])
    .factory('taskFactory', ['depFactory', 'EmpFactory', function (depFactory, EmpFactory, searchMethod) {
        var tasks = {};
        tasks.data = [
            {id:1, taskName: "Meetings", employees: [], roomNumber: 205, startDate:"2015-01-01", endDate: "2016-06-06"},
            {id:2, taskName: "Managing Employees", employees: [], roomNumber: 605, startDate:"2012-08-21", endDate: "2014-07-06"},
            {id:3, taskName: "Handling Finances", employees: [], roomNumber: 305, startDate:"2015-01-15", endDate: "2020-12-12"},
            {id:4, taskName: "Customer Service", employees: [],roomNumber: 555, startDate:"2017-03-17", endDate: "2020-06-09"},
            {id:5, taskName: "Planning", employees: [], roomNumber: 235, startDate:"2015-11-22", endDate: "2019-10-06"},
            {id:6, taskName: "Organizing", employees: [], roomNumber: 210, startDate:"2016-10-16", endDate: "2019-07-21"}
        ];
        tasks.deplist =[];
        tasks.addToFactory = function (tasks) {
            id++;
            tasks.id = id;
            this.tasks.push(tasks);
        }
        tasks.getData = function() {
            return tasks.data;
        };
        tasks.getData = function() {
            for (var index = 0; index < tasks.data.length; index++) {
                var taskId = tasks.data[index].id;
                var department = depFactory.getDepartmentForTaskId(taskId);
                tasks.data[index].department = department;
                var employees = EmpFactory.getEmployeesforTask(taskId);
                tasks.data[index].employees = employees;
            }
            return tasks.data;
        };
        return tasks;
    }])
    .directive('tasksDirective',function () {
        return {
            restrict:'E',
            replace:true,
            scope:{task:'='},
            //template: '<li><a ng-click="showDetails=! showDetails">{{task.taskName}}</a> ' +
            //'<div ng-show="showDetails">{{task.taskName}} {{task.employees}} {{task.roomNumber}}'+
            //' <div ng-repeat="emp in tasks.employees"> {{emp.firstName}}</div>{{dep.firstName}} {{dep.taskId}}</div></li>'
            templateUrl:'task/tasktemp.html'
        };
    });